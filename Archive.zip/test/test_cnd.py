import torch
import matplotlib.pyplot as plt
cnd = torch.load('ind/ind_yych.pt')
print(type(cnd[0]))

print(cnd)
plt.imshow(cnd[0])
plt.show()

# for idi, i in enumerate(cnd):
#     for idz, z in enumerate(i):
#         if z > 0:
#             print(idi, idz, z)
