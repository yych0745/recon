import torch
from torch import nn
import numpy as np
import math

# x = torch.zeros(400, 461)
s = np.zeros((1, 400, 461))
# s[0][100][100] = 1
for i in range(1,400,1):
    for j in range(1, 461, 1):
        x = i
        y = j + 500
        if round(math.sqrt(x * x + y * y), 0) in [520, 620, 720, 820, 920]:
            s[0][i][j] = 1
# print(x)
torch.save(s, 'ind/ind_yych.pt')