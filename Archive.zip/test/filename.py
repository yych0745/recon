import numpy as np
for i in np.arange(30, 50 + 0.02, 0.1):
    s = str(round(i, 1)) + "-1500.mat"
    print(s)
